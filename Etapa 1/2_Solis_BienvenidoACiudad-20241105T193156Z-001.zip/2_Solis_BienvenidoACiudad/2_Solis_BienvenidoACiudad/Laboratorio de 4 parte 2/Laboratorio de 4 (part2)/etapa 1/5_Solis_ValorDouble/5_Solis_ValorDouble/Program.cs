﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5_Solis_ValorDouble
{
    class Program
    {
        static void Main(string[] args)
        {
            Double altura, ancho, perimetro, area, diagonal;

            Console.WriteLine("dime la altura de tu triangulo rectangulo:");
            altura = int.Parse(Console.ReadLine());

            Console.WriteLine("ahora el ancho:");
            ancho = int.Parse(Console.ReadLine());

            perimetro = (altura * 2) + (ancho * 2);
            area = ancho * altura;
            diagonal = Math.Sqrt(((ancho * ancho) + (altura * altura)));

            Console.WriteLine("perimetro= " + perimetro);
            Console.WriteLine("area= " + area);
            Console.WriteLine("diagonal= " + diagonal);

            Console.ReadKey();
        }
    }
}
