﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7_Solis_AlReves
{
    class Program
    {
        static void Main(string[] args)
        {
            String L1, L2, L3;

            Console.WriteLine("elige 3 letras:");
            L1 = Console.ReadLine();
            L2 = Console.ReadLine();
            L3 = Console.ReadLine();

            Console.WriteLine("los di vuelta toma :D");
            Console.WriteLine(L3);
            Console.WriteLine(L2);
            Console.WriteLine(L1);

            Console.ReadKey();
        }
    }
}
