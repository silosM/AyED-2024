﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8_Solis_EsMayor
{
    class Program
    {
        static void Main(string[] args)
        {
            int edad;

            Console.WriteLine("Cuantos años tienes?");
            edad = int.Parse(Console.ReadLine());

            if (edad > 18) {
                Console.WriteLine("Tienes más de 18 ");
            }
            else if (edad < 18) {
                Console.WriteLine("Tienes menos de 18");
            }
            else
            {
                Console.WriteLine("tienes 18");
            }

            Console.ReadKey();
        }
    }
}
