﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_Solis_IngresePassword
{
    class Program
    {
        static void Main(string[] args)
        {
            String contraseña, intent;

            contraseña = "el pepo";

            Console.WriteLine("ingrese la contraseña:");
            intent = Console.ReadLine();

            if (contraseña == intent )
            {
                Console.WriteLine("la contraseña ingresada es correcta :D");
            }
            else
            {
                Console.WriteLine("la contraseña es incorrecta >:(");
            }

            Console.ReadKey();
        }
    }
}
